import java.util.*;
import java.util.regex.*;

public class ApplicationDemo {
	public static void main(String[] args) {
		
	
	Users u =new Users();
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter EmpId");
	int empId= sc.nextInt();
	u.getEmpId();
	
	System.out.println("Enter Name");
	String name=sc.next();
	u.setName(name);
	Pattern p1=Pattern.compile("[a-zA-Z]");
	Matcher m1=p1.matcher(name);
	
	System.out.println("Enter DOB");
	String DOB=sc.next();
	u.setDOB(DOB);
	String regex = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$";
	 
	Pattern pattern = Pattern.compile(regex);

	{
	    Matcher matcher = pattern.matcher(DOB);
	    System.out.println(DOB +" : "+ matcher.matches());
	}
	
	System.out.println("Enter PhoneNo");
	String PhoneNo=sc.next();
	u.setPhoneNo(PhoneNo);
	String regex1 = "^\\+[0-9]{1,3}\\.[0-9]{4,14}(?:x.+)?$";
	 
	Pattern p2 = Pattern.compile(regex);
	 
	  
	{
	    Matcher matcher = pattern.matcher(PhoneNo);
	    System.out.println(PhoneNo +" : "+ matcher.matches());
	}
	
	System.out.println("Enter Address");
	String Address=sc.next();
	u.setAddress(Address);
	
	System.out.println("Enter Qualification");
	String Qualification=sc.next();
	u.setQualification(Qualification);
	
	System.out.println("Enter EmailId");
	String EmailId=sc.next();
	u.setEmailId(EmailId);
	Pattern p = Pattern.compile("\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
	Matcher m = p.matcher("foobar@gmail.com");

	if (m.find())
	    System.out.println("Correct!");
	
	System.out.println("Enter Department");
	String Department=sc.next();
	u.setDepartment(Department);
	
	System.out.println("Enter Supervisor");
	String Supervisor=sc.next();
	u.setSupervisor(Supervisor);
	
	UsersBusinesslogic  ub=new UsersBusinesslogic();
	ub.validateUser(name);
	ub.registerUser(u);
	ub.ListEmployees(u);
	};
	{
	
	char ch = 0;
	while(ch=='y');

	}
	
}