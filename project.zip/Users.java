public class Users {
	private int empId;
	private String name;
	private String DOB;
	private String PhoneNo;
	private String Address;
	private String Qualification;
	private String EmailId;
	private String Department;
	private String Supervisor;
	private Skills s;
	static int id=100;
	public Users() {
		this.empId=id++;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDOB() {
		return DOB ;
	}
	public void setDOB(String DOB) {
		this.DOB=DOB;
	}
   
	public String getPhoneNo() {
		return PhoneNo ;
	}
	public void setPhoneNo(String PhoneNo) {
		this.PhoneNo=PhoneNo;
	}
	public String getAddress() {
		return Address ;
	}
	public void setAddress(String Address) {
		this.Address=Address;
	}
	public String getQualification() {
		return Qualification ;
	}
	public void setQualification(String Qualification) {
		this.Qualification=Qualification;
	}
	public String getEmailId() {
		return EmailId ;
	}
	public void setEmailId(String EmailId) {
		this.EmailId=EmailId;
	}
	public String getDepartment() {
		return Department ;
	}
	public void setDepartment(String Department) {
		this.Department=Department;
	}
	public String getSupervisor() {
		return Supervisor ;
	}
	public void setSupervisor(String Supervisor) {
		this.Supervisor=Supervisor;
	}
}