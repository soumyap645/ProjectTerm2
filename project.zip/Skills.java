
public class Skills {

}
